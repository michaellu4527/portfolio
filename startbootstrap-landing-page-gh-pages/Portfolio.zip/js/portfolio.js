// Auto scrolls to selected menu item on page
$(function () {
    $('a[href*=#]:not([href=#])').click(function () {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
});

// Highlight the top nav as scrolling occurs (doesn't work)
/*$(document).ready(function(){
	$('body').scrollspy({target: '#myScrollspy', offset:50});
});*/

