My personal portfolio site. It outlines my skills and a little about myself.

d